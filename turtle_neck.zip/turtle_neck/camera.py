"""카메라 입력 모듈: v4l2(GStreamer) / csi(Jetson) / webcam / file 을 같은 인터페이스로 제공"""
import re
import cv2


class Camera:
    def __init__(self, cap, name, flip=None):
        self.cap, self.name, self.flip = cap, name, flip

    def read(self):
        ok, frame = self.cap.read()
        if not ok:
            return None
        return frame if self.flip is None else cv2.flip(frame, self.flip)

    def release(self):
        self.cap.release()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.release()


def gstreamer_available():
    m = re.search(r"GStreamer:\s*(\w+)", cv2.getBuildInformation())
    return bool(m) and m.group(1).upper() == "YES"


# 최신 프레임만 받도록 버퍼 1개 유지 (지연 방지)
_SINK = ("queue leaky=downstream max-size-buffers=1 max-size-bytes=0 max-size-time=0 ! "
         "appsink drop=true max-buffers=1 sync=false")


def v4l2_pipeline(device=0, width=640, height=480, fps=30):
    return (
        f"v4l2src device=/dev/video{device} ! "
        f"video/x-raw,format=YUY2,width={width},height={height},framerate={fps}/1 ! "
        f"videoconvert ! video/x-raw,format=BGR ! {_SINK}"
    )


def csi_pipeline(sensor_id=0, width=640, height=480, fps=30):
    return (
        f"nvarguscamerasrc sensor-id={sensor_id} ! "
        f"video/x-raw(memory:NVMM),width=1280,height=720,framerate={fps}/1,format=NV12 ! "
        f"nvvidconv ! video/x-raw,width={width},height={height},format=BGRx ! "
        f"videoconvert ! video/x-raw,format=BGR ! {_SINK}"
    )


def _open_gst(pipeline, name):
    if not gstreamer_available():
        raise RuntimeError(
            "현재 OpenCV에 GStreamer 지원이 없습니다.\n"
            "pip로 설치한 opencv-python이 JetPack OpenCV를 덮어쓴 경우가 대부분입니다."
        )
    cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
    if not cap.isOpened():
        raise RuntimeError(f"카메라를 열 수 없습니다.\n파이프라인: {pipeline}")
    return cap


def open_camera(source="v4l2", device=0, path=None, width=640, height=480, fps=30, flip=None):
    if source == "v4l2":
        cap = _open_gst(v4l2_pipeline(device, width, height, fps), "v4l2")
    elif source == "csi":
        cap = _open_gst(csi_pipeline(device, width, height, fps), "csi")
    elif source == "webcam":
        cap = cv2.VideoCapture(device)
        if not cap.isOpened():
            raise RuntimeError(f"웹캠 {device}번을 열 수 없습니다. --device 값을 바꿔보세요.")
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    elif source == "file":
        cap = cv2.VideoCapture(path or "")
        if not cap.isOpened():
            raise RuntimeError(f"영상 파일을 열 수 없습니다: {path}")
    else:
        raise ValueError(f"알 수 없는 소스: {source}")
    return Camera(cap, f"{source}:{path if source == 'file' else device}", flip)


def add_camera_args(parser):
    g = parser.add_argument_group("camera")
    g.add_argument("--source", choices=["v4l2", "csi", "webcam", "file"], default="v4l2")
    g.add_argument("--device", type=int, default=0, help="/dev/videoN 또는 웹캠 번호, CSI 센서 번호")
    g.add_argument("--path", help="영상 파일 경로 (source=file)")
    g.add_argument("--width", type=int, default=640)
    g.add_argument("--height", type=int, default=480)
    g.add_argument("--fps", type=int, default=30)
    g.add_argument("--flip", type=int, choices=[-1, 0, 1], default=None,
                   help="0 상하 반전, 1 좌우 반전, -1 둘 다")
    return parser


def camera_from_args(args):
    return open_camera(args.source, args.device, args.path,
                       args.width, args.height, args.fps, args.flip)
