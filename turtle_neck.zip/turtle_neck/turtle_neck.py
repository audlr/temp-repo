"""
거북목 판정기
- 측면 카메라, 목 뒤 C7(고개 숙이면 튀어나오는 뼈)에 색 스티커 부착
- C7: 색 분할 + 윤곽선 + 칼만 추적 / 귀: MediaPipe Pose Landmarker
- 판정: CVA = C7→귀 직선과 수평선의 각도 (작을수록 거북목)

실행
  Jetson (v4l2) : python turtle_neck.py --flip 0
  Jetson (CSI)  : python turtle_neck.py --source csi
  노트북 웹캠   : python turtle_neck.py --source webcam
  영상 파일     : python turtle_neck.py --source file --path side.mp4
  화면 없이     : python turtle_neck.py --headless
키: q 종료, r 통계 초기화
"""
import argparse
import math
import os
import time
from collections import deque
from contextlib import closing

import cv2
import numpy as np
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

from camera import add_camera_args, camera_from_args

# 코드 파일 기준 경로라 실행 위치와 무관
DEFAULT_MODEL = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "..", "src", "models", "MediaPipe", "pose_landmarker.task")

GOOD_DEG = 55
WARN_DEG = 50
ALERT_SEC = 5
MIN_AREA = 80
LOST_LIMIT = 15
HSV_DEFAULT = ((35, 80, 60), (85, 255, 255))   # 초록 스티커

PL = vision.PoseLandmark
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
KERNEL = np.ones((5, 5), np.uint8)
FONT = cv2.FONT_HERSHEY_SIMPLEX


class HSVControl:
    """GUI 모드는 트랙바, headless 모드는 기본값 사용"""
    NAMES = ("H_low", "S_low", "V_low", "H_high", "S_high", "V_high")
    MAX = (179, 255, 255, 179, 255, 255)

    def __init__(self, gui, win="mask"):
        self.win, self.gui = win, gui
        self.default = (*HSV_DEFAULT[0], *HSV_DEFAULT[1])
        if gui:
            cv2.namedWindow(win, cv2.WINDOW_NORMAL)
            for n, v, mx in zip(self.NAMES, self.default, self.MAX):
                cv2.createTrackbar(n, win, v, mx, lambda _: None)

    def range(self):
        v = [cv2.getTrackbarPos(n, self.win) for n in self.NAMES] if self.gui else self.default
        return np.array(v[:3]), np.array(v[3:])


class MarkerTracker:
    """등속 모델 칼만 필터. 잠깐 가려지면 예측값 유지"""

    def __init__(self):
        kf = cv2.KalmanFilter(4, 2)
        kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
        kf.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1],
                                        [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
        kf.processNoiseCov = np.eye(4, dtype=np.float32) * 1e-2
        kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 1e-1
        self.kf, self.on, self.lost = kf, False, 0
        self.trail = deque(maxlen=40)

    def update(self, meas):
        if not self.on:
            if meas is None:
                return None
            self.kf.statePost = np.array([[meas[0]], [meas[1]], [0], [0]], np.float32)
            self.on = True

        est = self.kf.predict()
        if meas is not None:
            est = self.kf.correct(np.array([[meas[0]], [meas[1]]], np.float32))
            self.lost = 0
        else:
            self.lost += 1
            if self.lost > LOST_LIMIT:
                self.on = False
                self.trail.clear()
                return None

        pt = (float(est[0, 0]), float(est[1, 0]))
        self.trail.append(pt)
        return pt


# ---------------- 영상 처리 ----------------
def enhance(frame):
    adj = cv2.convertScaleAbs(frame, alpha=1.1, beta=10)
    l, a, b = cv2.split(cv2.cvtColor(adj, cv2.COLOR_BGR2LAB))
    return cv2.cvtColor(cv2.merge((clahe.apply(l), a, b)), cv2.COLOR_LAB2BGR)


def find_marker(img, lo, hi):
    """화면 전체에서 색 분할 후 가장 큰 윤곽선의 중심 반환"""
    hsv = cv2.cvtColor(cv2.GaussianBlur(img, (7, 7), 0), cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lo, hi)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, KERNEL)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, KERNEL)

    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = [c for c in cnts if cv2.contourArea(c) > MIN_AREA]
    if not cnts:
        return None, mask, None
    c = max(cnts, key=cv2.contourArea)
    M = cv2.moments(c)
    return (M["m10"] / M["m00"], M["m01"] / M["m00"]), mask, c


def create_pose(model_path):
    options = vision.PoseLandmarkerOptions(
        base_options=python.BaseOptions(model_asset_path=os.path.normpath(model_path)),
        num_poses=1)
    return vision.PoseLandmarker.create_from_options(options)


def run_pose(pose, img):
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    res = pose.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb))
    return res.pose_landmarks[0] if res.pose_landmarks else None


def pick_side(lm):
    """카메라 쪽(가시성이 높은) 귀/어깨 선택"""
    if lm[PL.LEFT_EAR].visibility >= lm[PL.RIGHT_EAR].visibility:
        return lm[PL.LEFT_EAR], lm[PL.LEFT_SHOULDER]
    return lm[PL.RIGHT_EAR], lm[PL.RIGHT_SHOULDER]


# ---------------- 판정 ----------------
def calc_cva(ear, c7):
    return math.degrees(math.atan2(c7[1] - ear[1], abs(ear[0] - c7[0])))


def classify(angle):
    if angle >= GOOD_DEG:
        return "GOOD", (0, 200, 0)
    if angle >= WARN_DEG:
        return "WARNING", (0, 200, 255)
    return "TURTLE NECK", (0, 0, 255)


# ---------------- 표현 ----------------
def draw_overlay(img, ear, c7, angle, status, color, fallback):
    e, c = tuple(map(int, ear)), tuple(map(int, c7))
    front = e[0] >= c[0]
    cv2.line(img, c, (c[0] + (100 if front else -100), c[1]), (200, 200, 200), 2)
    cv2.line(img, c, e, color, 3)
    cv2.circle(img, e, 8, color, -1)
    cv2.circle(img, c, 8, (255, 255, 0), -1)
    cv2.ellipse(img, c, (50, 50), 0, 0 if front else 180,
                -angle if front else 180 + angle, color, 2)
    cv2.putText(img, f"{angle:.1f} deg", (c[0] + 10, c[1] + 30), FONT, 0.7, color, 2)
    label = status + (" (shoulder fallback)" if fallback else "")
    cv2.putText(img, label, (20, 40), FONT, 1.0, color, 3)


def draw_stats(img, good_t, bad_t, fps):
    h, w = img.shape[:2]
    total = good_t + bad_t
    ratio = good_t / total if total > 0 else 1.0
    x0, y0, bw = 20, h - 40, w - 40
    cv2.rectangle(img, (x0, y0), (x0 + bw, y0 + 20), (0, 0, 255), -1)
    cv2.rectangle(img, (x0, y0), (x0 + int(bw * ratio), y0 + 20), (0, 200, 0), -1)
    cv2.putText(img, f"Good posture {ratio * 100:.0f}%  ({total:.0f}s)",
                (x0, y0 - 8), FONT, 0.6, (255, 255, 255), 2)
    cv2.putText(img, f"{fps:.1f} FPS", (w - 130, 30), FONT, 0.6, (255, 255, 255), 2)


def draw_alert(img, sec):
    red = np.full_like(img, (0, 0, 255))
    cv2.addWeighted(red, 0.3, img, 0.7, 0, img)
    cv2.putText(img, f"STRAIGHTEN UP!  {sec:.0f}s", (20, 90), FONT, 1.1, (255, 255, 255), 3)


# ---------------- 메인 ----------------
def main(cam, model_path=DEFAULT_MODEL, gui=True):
    hsv_ctl = HSVControl(gui)
    tracker = MarkerTracker()
    angles = deque(maxlen=10)
    good_t = bad_t = 0.0
    bad_since = None
    prev, last_log = time.time(), 0.0
    fps = 0.0

    with closing(create_pose(model_path)) as pose:   # 종료 시 pose.close() 자동 호출
        while True:
            frame = cam.read()
            if frame is None:
                break
            now = time.time()
            dt, prev = now - prev, now
            if dt > 0:
                fps = 0.9 * fps + 0.1 / dt

            img = enhance(frame)
            h, w = img.shape[:2]
            meas, mask, cnt = find_marker(img, *hsv_ctl.range())
            c7 = tracker.update(meas)
            lm = run_pose(pose, img)
            out = img.copy()
            status, angle = None, None

            if cnt is not None:
                cv2.drawContours(out, [cnt], -1, (255, 255, 0), 2)
            pts = [tuple(map(int, p)) for p in tracker.trail]
            for p1, p2 in zip(pts, pts[1:]):
                cv2.line(out, p1, p2, (255, 200, 0), 1)

            if lm is not None:
                ear_lm, sh_lm = pick_side(lm)
                ear = (ear_lm.x * w, ear_lm.y * h)
                fallback = c7 is None
                base = c7 if c7 is not None else (sh_lm.x * w, sh_lm.y * h)   # 마커 없으면 어깨로 대체

                angles.append(calc_cva(ear, base))
                angle = sum(angles) / len(angles)
                status, color = classify(angle)
                draw_overlay(out, ear, base, angle, status, color, fallback)

                if status == "TURTLE NECK":
                    bad_t += dt
                    bad_since = bad_since or now
                    if now - bad_since >= ALERT_SEC:
                        draw_alert(out, now - bad_since)
                else:
                    good_t += dt
                    bad_since = None
            else:
                bad_since = None
                cv2.putText(out, "No person detected", (20, 40), FONT, 1.0, (0, 0, 255), 2)

            if not gui:
                if now - last_log >= 1:
                    a = f"{angle:.1f}deg" if angle is not None else "-"
                    print(f"[{status or 'NO PERSON'}] {a}  {fps:.1f}fps")
                    last_log = now
                continue

            draw_stats(out, good_t, bad_t, fps)
            cv2.imshow("Turtle Neck Detector", out)
            cv2.imshow(hsv_ctl.win, mask)

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            if key == ord("r"):
                good_t = bad_t = 0.0
                bad_since = None

    if gui:
        cv2.destroyAllWindows()


if __name__ == "__main__":
    parser = add_camera_args(argparse.ArgumentParser(description="거북목 판정기"))
    parser.add_argument("--headless", action="store_true", help="화면 없이 터미널 출력만")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="pose_landmarker .task 파일 경로")
    args = parser.parse_args()

    with camera_from_args(args) as cam:
        print(f"[camera] {cam.name}")
        try:
            main(cam, args.model, gui=not args.headless)
        except KeyboardInterrupt:
            pass
