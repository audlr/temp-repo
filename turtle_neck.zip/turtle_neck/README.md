# 거북목 판정기

측면 카메라로 CVA(두개척추각)를 측정해 거북목 여부를 실시간으로 판정합니다.

## 원리
- 목 뒤 C7(고개를 숙이면 튀어나오는 뼈)에 **초록**, 귀 앞 연골(이주)에 **분홍** 스티커 부착
- 색 분할 → 윤곽선 → 칼만 필터로 두 마커 추적
- MediaPipe Pose Landmarker로 머리·목 주변만 탐색하고, 측면 자세인지 확인
- CVA = C7→귀 직선과 수평선 사이 각도 (55° 이상 정상, 50~55° 주의, 50° 미만 거북목)

## 파일
| 파일 | 내용 |
|---|---|
| `camera.py` | 카메라 입력 (v4l2 / CSI / 웹캠 / 영상 파일) |
| `turtle_neck.py` | 검출·추적·판정·화면 출력 |

## 준비
1. 모델 파일을 `src/models/MediaPipe/pose_landmarker_lite.task`에 둡니다.
   [다운로드](https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task) · 다른 경로면 `--model`로 지정
2. 패키지 설치
   - Jetson: 수업 환경 그대로 사용. pip로 `opencv-python`을 설치하면 GStreamer 지원이 사라지니 주의
   - 노트북: `pip install -r requirements.txt`

## 실행
```bash
python turtle_neck.py --flip 0                          # Jetson USB 카메라 (v4l2, 상하 반전)
python turtle_neck.py --source csi                      # Jetson CSI 카메라
python turtle_neck.py --source webcam                   # 노트북 웹캠
python turtle_neck.py --source file --path side.mp4     # 녹화 영상
python turtle_neck.py --headless                        # 화면 없이 (SSH)
```
- `--flip`: 0 상하, 1 좌우, -1 둘 다 반전
- `--device`: `/dev/videoN` 번호 (웹캠은 카메라 번호)
- 키: `q` 종료, `r` 통계 초기화

## 화면 메시지
| 메시지 | 의미 / 조치 |
|---|---|
| `C7 MARKER LOST` | 초록 마커 미검출 → `mask_c7` 창 트랙바로 HSV 조정 |
| `(ear: pose)` | 분홍 마커 미검출, Pose 귀 좌표로 대신 측정 |
| `TURN SIDEWAYS` | 몸이 카메라를 향함 → 옆으로 서기 |
| `NO PERSON` | 사람 미검출 |

판정 기준 각도는 `turtle_neck.py` 상단의 `GOOD_DEG`, `WARN_DEG`에서 조정합니다.
