# 거북목 판정기

측면 카메라로 CVA(두개척추각)를 측정해 거북목 여부를 실시간으로 판정합니다.

## 원리
- 목 뒤 C7(고개를 숙이면 튀어나오는 뼈)에 **초록** 스티커 부착
- C7: 색 분할 → 윤곽선 → 칼만 필터 추적 / 귀: MediaPipe Pose Landmarker
- CVA = C7→귀 직선과 수평선 사이 각도 (55° 이상 정상, 50~55° 주의, 50° 미만 거북목)

## 파일
| 파일 | 내용 |
|---|---|
| `camera.py` | 카메라 입력 (v4l2 / CSI / 웹캠 / 영상 파일) |
| `turtle_neck.py` | 검출·추적·판정·화면 출력 |

## 폴더 구조
```
프로젝트/
├── 20261018/                              ← 코드
└── src/models/MediaPipe/pose_landmarker.task
```
모델 경로는 `turtle_neck.py` 상단 `DEFAULT_MODEL`에서 바꾸거나 `--model`로 지정합니다.

## 실행
```bash
python turtle_neck.py --flip 0                          # Jetson USB 카메라 (v4l2, 상하 반전)
python turtle_neck.py --source csi                      # Jetson CSI 카메라
python turtle_neck.py --source webcam                   # 노트북 웹캠
python turtle_neck.py --source file --path side.mp4     # 녹화 영상
python turtle_neck.py --headless                        # 화면 없이 (SSH)
```
- `--flip`: 0 상하, 1 좌우, -1 둘 다 반전
- `--device`: `/dev/videoN` 번호 (웹캠은 카메라 번호)
- 키: `q` 종료, `r` 통계 초기화

## 사용 팁
- `mask` 창 트랙바로 스티커 색에 맞게 HSV 범위를 조정합니다. 스티커만 흰색으로 보이면 정상입니다.
- `(shoulder fallback)`이 뜨면 마커를 놓쳐 어깨 좌표로 대신 측정 중인 상태입니다.
- 판정 기준 각도는 `turtle_neck.py` 상단 `GOOD_DEG`, `WARN_DEG`에서 조정합니다.
- Jetson에서 pip로 `opencv-python`을 설치하면 GStreamer 지원이 사라지니 주의하세요.
