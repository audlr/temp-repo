import cv2
import math
import time
import numpy as np
import mediapipe as mp
from collections import deque
from mediapipe.tasks import python
from mediapipe.tasks.python import vision


# ---------------- 설정 ----------------
WARN_SCORE, BAD_SCORE = 0.12, 0.20  # 기준 자세 대비 변화량 (목 짧아짐 + 얼굴 커짐) 이상이면 주의 / 거북목
TILT_DEG = 5                        # 어깨 기울기가 이 각도 이상이면 경고
CALIB_SEC = 3                       # 캘리브레이션 시간(초)
ALERT_SEC = 5                       # 거북목 자세가 이 시간(초) 이상 지속되면 경고
MIN_AREA = 80                       # 마커로 인정할 최소 윤곽선 면적
LOST_LIMIT = 15                     # 마커를 이 프레임 수 이상 놓치면 추적 해제
FLIP = 0                            # 0 상하 반전, 1 좌우 반전, None 반전 없음 (노트북 웹캠은 None)

base_option = python.BaseOptions(model_asset_path="src/models/MediaPipe/pose_landmarker.task")  # 모델 경로 지정하는 옵션
options = vision.PoseLandmarkerOptions(base_options=base_option, num_poses=1)                   # 모델 경로와 최대 사람 수 지정
pose_detector = vision.PoseLandmarker.create_from_options(options)                              # 해당 옵션으로 자세 검출하는 객체 생성
connections = vision.PoseLandmarksConnections.POSE_LANDMARKS                                    # 각 landmark를 잇는 연결선 정보
PL = vision.PoseLandmark                                                                        # landmark 이름 (NOSE, LEFT_EYE 등)


# ---------------- 카메라 ----------------
pipeline = (
    "v4l2src device=/dev/video0 ! "
    "video/x-raw,format=YUY2,width=640,height=480,framerate=30/1 ! "
    "videoconvert ! video/x-raw,format=BGR ! "
    "queue leaky=downstream max-size-buffers=1 "
    "max-size-bytes=0 max-size-time=0 ! "
    "appsink drop=true max-buffers=1 sync=false"
)

cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)    # Jetson
# cap = cv2.VideoCapture(0)                            # 노트북 웹캠 (FLIP = None 으로 변경)


# ---------------- 어깨 마커 HSV 트랙바 (기본값: 초록 스티커) ----------------
cv2.namedWindow("mask")
for name, init, mx in [("H_low", 35, 179), ("H_high", 85, 179),
                       ("S_low", 80, 255), ("S_high", 255, 255),
                       ("V_low", 60, 255), ("V_high", 255, 255)]:
    cv2.createTrackbar(name, "mask", init, mx, lambda _: None)


# ---------------- 어깨 마커 추적 (칼만 필터, 화면 왼쪽/오른쪽 어깨 각각) ----------------
def make_tracker():
    kf = cv2.KalmanFilter(4, 2)                                                                # 상태: x, y, vx, vy / 측정: x, y
    kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
    kf.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)  # 등속 운동 모델
    kf.processNoiseCov = np.eye(4, dtype=np.float32) * 1e-2
    kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 1e-1
    return {"kf": kf, "on": False, "lost": 0, "pos": None}


def update_tracker(t, meas):
    """측정값으로 보정, 없으면 예측값 유지. LOST_LIMIT 넘게 놓치면 None"""
    if not t["on"]:
        if meas is None:
            return None
        t["kf"].statePost = np.array([[meas[0]], [meas[1]], [0], [0]], np.float32)
        t["on"] = True
    est = t["kf"].predict()
    if meas is not None:
        est = t["kf"].correct(np.array([[meas[0]], [meas[1]]], np.float32))
        t["lost"] = 0
    else:
        t["lost"] += 1
        if t["lost"] > LOST_LIMIT:
            t["on"], t["pos"] = False, None
            return None
    t["pos"] = (float(est[0, 0]), float(est[1, 0]))
    return t["pos"]


trackers = {"L": make_tracker(), "R": make_tracker()}     # 화면 기준 왼쪽 / 오른쪽 어깨
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
kernel = np.ones((5, 5), np.uint8)
scores = deque(maxlen=10)       # 점수 이동평균용
calib, calib_start = [], None   # 캘리브레이션 샘플, 시작 시각
base = None                     # 기준 자세 (목 길이 비율, 얼굴 크기 비율)
good_t = bad_t = 0.0            # 바른 자세 / 거북목 누적 시간
bad_since = None                # 거북목 자세 시작 시각
prev = time.time()

while True:
    ret, frame = cap.read()

    if not ret:
        break
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
    if key == ord("c"):         # 다시 캘리브레이션
        base, calib, calib_start = None, [], None
    if key == ord("r"):         # 통계 초기화
        good_t = bad_t = 0.0
        bad_since = None

    now = time.time()
    dt, prev = now - prev, now

    # 이미지 반전, 밝기/대비 조정, LAB 색공간에서 CLAHE로 조명 보정 (전처리)
    if FLIP is not None:
        frame = cv2.flip(frame, FLIP)
    frame = cv2.convertScaleAbs(frame, alpha=1.1, beta=10)
    l, a, b = cv2.split(cv2.cvtColor(frame, cv2.COLOR_BGR2LAB))
    frame = cv2.cvtColor(cv2.merge((clahe.apply(l), a, b)), cv2.COLOR_LAB2BGR)
    h, w = frame.shape[:2]      # 프레임 높이와 너비

    # 블러 후 HSV 변환, 트랙바 범위로 마스크 생성, 모폴로지로 잡티 제거 및 구멍 메우기
    hsv = cv2.cvtColor(cv2.GaussianBlur(frame, (7, 7), 0), cv2.COLOR_BGR2HSV)
    lo = np.array([cv2.getTrackbarPos(n, "mask") for n in ("H_low", "S_low", "V_low")])
    hi = np.array([cv2.getTrackbarPos(n, "mask") for n in ("H_high", "S_high", "V_high")])
    mask = cv2.inRange(hsv, lo, hi)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    # 면적이 큰 윤곽선 2개의 중심을 어깨 마커 후보로 사용
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted([c for c in contours if cv2.contourArea(c) > MIN_AREA], key=cv2.contourArea, reverse=True)[:2]
    centers = []
    for c in contours:
        M = cv2.moments(c)
        centers.append((M["m10"] / M["m00"], M["m01"] / M["m00"]))
        cv2.drawContours(frame, [c], -1, (255, 255, 0), 2)

    # 프레임 내 자세 탐지
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = pose_detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb))
    pose = result.pose_landmarks[0] if result.pose_landmarks else None
    pts = [(int(p.x * w), int(p.y * h)) for p in pose] if pose else None    # 프레임 크기 기준 각 landmark 좌표

    # Pose 어깨를 화면 왼쪽/오른쪽으로 정렬 (마커 대체값 및 마커 좌우 구분 기준)
    pose_sh = None
    if pts:
        s1, s2 = pts[PL.LEFT_SHOULDER], pts[PL.RIGHT_SHOULDER]
        pose_sh = {"L": min(s1, s2), "R": max(s1, s2)}

    # 마커를 왼쪽/오른쪽 어깨에 배정: 2개면 x좌표 순, 1개면 기준점(이전 위치 또는 Pose 어깨)에 가까운 쪽
    meas = {"L": None, "R": None}
    if len(centers) == 2:
        meas["L"], meas["R"] = sorted(centers)
    elif len(centers) == 1:
        ref = {k: trackers[k]["pos"] or (pose_sh[k] if pose_sh else None) for k in meas}
        if ref["L"] and ref["R"]:
            side = min(meas, key=lambda k: math.dist(centers[0], ref[k]))
        else:
            side = "L" if centers[0][0] < w / 2 else "R"
        meas[side] = centers[0]
    shoulders = {k: update_tracker(trackers[k], meas[k]) for k in meas}

    status, color = None, (0, 200, 255)

    if pts:
        # landmark를 연결하는 선 (skeleton)과 점 그리기
        for c in connections:
            cv2.line(frame, pts[c.start], pts[c.end], (0, 255, 0), 1)
        for pt in pts:
            cv2.circle(frame, pt, 3, (255, 0, 0), -1)

        # 마커를 놓친 어깨는 Pose 어깨로 대체
        fallback = [k for k in shoulders if shoulders[k] is None]
        sl = tuple(map(int, shoulders["L"] or pose_sh["L"]))
        sr = tuple(map(int, shoulders["R"] or pose_sh["R"]))
        nose = pts[PL.NOSE]
        eye_l, eye_r = pts[PL.LEFT_EYE], pts[PL.RIGHT_EYE]

        # 어깨 너비로 정규화한 목 길이(코~어깨 중점 세로 거리)와 얼굴 크기(눈 사이 거리)
        sw = max(math.dist(sl, sr), 1)
        mid = ((sl[0] + sr[0]) // 2, (sl[1] + sr[1]) // 2)
        neck = (mid[1] - nose[1]) / sw
        face = math.dist(eye_l, eye_r) / sw
        tilt = math.degrees(math.atan2(sr[1] - sl[1], sr[0] - sl[0]))

        # 어깨선, 목 길이 선, 눈 사이 선 그리기
        cv2.line(frame, sl, sr, (255, 255, 0), 3)
        cv2.circle(frame, sl, 8, (255, 255, 0), -1)
        cv2.circle(frame, sr, 8, (255, 255, 0), -1)
        cv2.line(frame, mid, (mid[0], nose[1]), (255, 0, 255), 2)
        cv2.line(frame, eye_l, eye_r, (255, 0, 255), 2)

        if base is None:
            # 캘리브레이션: 바른 자세로 CALIB_SEC 동안 평균값을 기준으로 저장
            calib_start = calib_start or now
            calib.append((neck, face))
            remain = CALIB_SEC - (now - calib_start)
            cv2.putText(frame, f"CALIBRATING... sit straight {remain:.0f}s", (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 200, 255), 2)
            if remain <= 0:
                base = tuple(np.mean(calib, axis=0))
        else:
            # 점수 = 목 짧아진 비율 + 얼굴 커진 비율 (머리가 앞으로 나오고 처질수록 커짐)
            neck_drop = 1 - neck / base[0]
            face_grow = face / base[1] - 1
            scores.append(neck_drop + face_grow)
            score = sum(scores) / len(scores)

            if score >= BAD_SCORE:
                status, color = "TURTLE NECK", (0, 0, 255)
            elif score >= WARN_SCORE:
                status, color = "WARNING", (0, 200, 255)
            else:
                status, color = "GOOD", (0, 200, 0)

            label = status + (f" (pose shoulder: {','.join(fallback)})" if fallback else "")
            cv2.putText(frame, label, (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
            cv2.putText(frame, f"Neck {-neck_drop * 100:+.0f}%  Face {face_grow * 100:+.0f}%", (20, 65), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        tilt_color = (0, 0, 255) if abs(tilt) >= TILT_DEG else (255, 255, 255)
        cv2.putText(frame, f"Shoulder tilt {tilt:+.1f} deg", (20, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.6, tilt_color, 2)
    else:
        cv2.putText(frame, "No person detected", (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

    # 시간 누적, 거북목이 ALERT_SEC 이상 지속되면 화면 전체 빨간 경고
    if status == "TURTLE NECK":
        bad_t += dt
        bad_since = bad_since or now
        if now - bad_since >= ALERT_SEC:
            red = np.full_like(frame, (0, 0, 255))
            cv2.addWeighted(red, 0.3, frame, 0.7, 0, frame)
            cv2.putText(frame, f"STRAIGHTEN UP! {now - bad_since:.0f}s", (20, 125), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)
    else:
        bad_since = None
        if status is not None:
            good_t += dt

    # 하단 바른 자세 비율 바와 우측 상단 FPS
    total = good_t + bad_t
    ratio = good_t / total if total > 0 else 1.0
    cv2.rectangle(frame, (20, h - 40), (w - 20, h - 20), (0, 0, 255), -1)
    cv2.rectangle(frame, (20, h - 40), (20 + int((w - 40) * ratio), h - 20), (0, 200, 0), -1)
    cv2.putText(frame, f"Good posture {ratio * 100:.0f}% ({total:.0f}s)", (20, h - 48), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    cv2.putText(frame, f"{1 / dt if dt > 0 else 0:.1f} FPS", (w - 110, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    cv2.imshow("Turtle Neck Detector", frame)
    cv2.imshow("mask", mask)

pose_detector.close()
cap.release()
cv2.destroyAllWindows()
