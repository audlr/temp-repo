import cv2
import math
import time
import numpy as np
import mediapipe as mp
from collections import deque
from mediapipe.tasks import python
from mediapipe.tasks.python import vision


# ---------------- 설정 ----------------
MODEL_PATH = "src/models/MediaPipe/pose_landmarker.task"

# 판정
WARN_SCORE, BAD_SCORE = 0.15, 0.20  # 기준 자세 대비 변화량 (목 짧아짐 + 얼굴 커짐) 이상이면 주의 / 거북목
TILT_DEG = 5                        # 어깨 기울기가 이 각도 이상이면 경고
SMOOTH_N = 10                       # 점수 이동평균 프레임 수
CALIB_SEC = 10                      # 캘리브레이션 시간(초)
ALERT_SEC = 5                       # 거북목 자세가 이 시간(초) 이상 지속되면 경고

# 전처리
ALPHA, BETA = 1.1, 10               # 대비, 밝기
CLAHE_CLIP, CLAHE_TILE = 2.0, 8     # CLAHE 대비 제한, 타일 크기
BLUR_K, MORPH_K = 7, 5              # 가우시안 블러, 모폴로지 커널 크기

# 어깨 마커
HSV_LOW, HSV_HIGH = (35, 80, 60), (85, 255, 255)   # 트랙바 기본값 (초록 스티커)
SEARCH_RATIO = 0.35                 # Pose 어깨에서 어깨 너비의 이 비율 이내 윤곽선만 마커로 인정
MIN_AREA = 80                       # 마커로 인정할 최소 윤곽선 면적
LOST_LIMIT = 15                     # 마커를 이 프레임 수 이상 놓치면 추적 해제
PROCESS_NOISE, MEASURE_NOISE = 1e-2, 1e-1          # 칼만 필터 노이즈 (측정 노이즈가 클수록 부드럽지만 느림)

# 표시 (BGR)
GREEN, YELLOW, RED, WHITE = (0, 200, 0), (0, 200, 255), (0, 0, 255), (255, 255, 255)
LINE, DOT = 3, 5                    # 선 두께, 점 반지름
TEXT, TEXT_L = 0.5, 0.6             # 글자 크기 (보통, 강조)
PAD = 15                            # 화면 여백


def put_text(img, text, org, color=WHITE, scale=TEXT):
    """작고 얇은 글씨, 안티앨리어싱으로 부드럽게 출력"""
    cv2.putText(img, text, org, cv2.FONT_HERSHEY_SIMPLEX, scale, color, 1, cv2.LINE_AA)


base_option = python.BaseOptions(model_asset_path=MODEL_PATH)                                   # 모델 경로 지정하는 옵션
options = vision.PoseLandmarkerOptions(base_options=base_option, num_poses=1)                   # 모델 경로와 최대 사람 수 지정
pose_detector = vision.PoseLandmarker.create_from_options(options)                              # 해당 옵션으로 자세 검출하는 객체 생성
PL = vision.PoseLandmark                                                                        # landmark 이름 (NOSE, LEFT_EYE 등)

pipeline = (
    "v4l2src device=/dev/video0 ! "
    "video/x-raw,format=YUY2,width=640,height=480,framerate=30/1 ! "
    "videoconvert ! video/x-raw,format=BGR ! "
    "queue leaky=downstream max-size-buffers=1 "
    "max-size-bytes=0 max-size-time=0 ! "
    "appsink drop=true max-buffers=1 sync=false"
)
cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)    # Jetson
# cap = cv2.VideoCapture(0)                            # 노트북 웹캠

# 어깨 마커 HSV 트랙바
cv2.namedWindow("mask")
for name, init, mx in zip(("H_low", "S_low", "V_low", "H_high", "S_high", "V_high"),
                          HSV_LOW + HSV_HIGH, (179, 255, 255) * 2):
    cv2.createTrackbar(name, "mask", init, mx, lambda _: None)


# ---------------- 어깨 마커 추적 (칼만 필터, 화면 왼쪽/오른쪽 어깨 각각) ----------------
def make_tracker():
    kf = cv2.KalmanFilter(4, 2)                                                                # 상태: x, y, vx, vy / 측정: x, y
    kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
    kf.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)  # 등속 운동 모델
    kf.processNoiseCov = np.eye(4, dtype=np.float32) * PROCESS_NOISE
    kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * MEASURE_NOISE
    return {"kf": kf, "on": False, "lost": 0}


def update_tracker(t, meas):
    """측정값으로 보정, 없으면 예측값 유지. LOST_LIMIT 넘게 놓치면 None"""
    if not t["on"]:
        if meas is None:
            return None
        t["kf"].statePost = np.array([[meas[0]], [meas[1]], [0], [0]], np.float32)
        t["on"] = True
    est = t["kf"].predict()
    if meas is not None:
        est = t["kf"].correct(np.array([[meas[0]], [meas[1]]], np.float32))
        t["lost"] = 0
    else:
        t["lost"] += 1
        if t["lost"] > LOST_LIMIT:
            t["on"] = False
            return None
    return (int(est[0, 0]), int(est[1, 0]))


trackers = {"L": make_tracker(), "R": make_tracker()}     # 화면 기준 왼쪽 / 오른쪽 어깨
clahe = cv2.createCLAHE(clipLimit=CLAHE_CLIP, tileGridSize=(CLAHE_TILE, CLAHE_TILE))
kernel = np.ones((MORPH_K, MORPH_K), np.uint8)
scores = deque(maxlen=SMOOTH_N)       # 점수 이동평균용
calib, calib_start = [], None   # 캘리브레이션 샘플, 시작 시각
base = None                     # 기준 자세 (목 길이 비율, 얼굴 크기 비율)
good_t = bad_t = 0.0            # 바른 자세 / 거북목 누적 시간
bad_since = None                # 거북목 자세 시작 시각
prev = time.time()

while True:
    ret, frame = cap.read()

    if not ret:
        break
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
    if key == ord("c"):         # 다시 캘리브레이션
        base, calib, calib_start = None, [], None

    now = time.time()
    dt, prev = now - prev, now

    # 밝기/대비 조정, LAB 색공간에서 CLAHE로 조명 보정 (전처리)
    frame = cv2.convertScaleAbs(frame, alpha=ALPHA, beta=BETA)
    l, a, b = cv2.split(cv2.cvtColor(frame, cv2.COLOR_BGR2LAB))
    frame = cv2.cvtColor(cv2.merge((clahe.apply(l), a, b)), cv2.COLOR_LAB2BGR)
    h, w = frame.shape[:2]      # 프레임 높이와 너비

    # 블러 후 HSV 변환, 트랙바 범위로 마스크 생성, 모폴로지로 잡티 제거 및 구멍 메우기
    hsv = cv2.cvtColor(cv2.GaussianBlur(frame, (BLUR_K, BLUR_K), 0), cv2.COLOR_BGR2HSV)
    lo = np.array([cv2.getTrackbarPos(n, "mask") for n in ("H_low", "S_low", "V_low")])
    hi = np.array([cv2.getTrackbarPos(n, "mask") for n in ("H_high", "S_high", "V_high")])
    mask = cv2.inRange(hsv, lo, hi)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    # 프레임 내 자세 탐지
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = pose_detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb))
    status = None

    if result.pose_landmarks:
        pts = [(int(p.x * w), int(p.y * h)) for p in result.pose_landmarks[0]]    # 프레임 크기 기준 각 landmark 좌표

        # Pose 어깨를 화면 왼쪽/오른쪽으로 정렬
        s1, s2 = pts[PL.LEFT_SHOULDER], pts[PL.RIGHT_SHOULDER]
        pose_sh = {"L": min(s1, s2), "R": max(s1, s2)}
        radius = SEARCH_RATIO * math.dist(s1, s2)

        # Pose 어깨 반경 안에서 가장 가까운 윤곽선만 마커로 인정 (배경의 같은 색 물체 제거)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        shoulders, fallback = {}, []
        for k in ("L", "R"):
            near = []
            for c in contours:
                M = cv2.moments(c)
                if cv2.contourArea(c) > MIN_AREA:
                    p = (M["m10"] / M["m00"], M["m01"] / M["m00"])
                    if math.dist(p, pose_sh[k]) < radius:
                        near.append((math.dist(p, pose_sh[k]), p, c))
            meas = None
            if near:
                _, meas, _ = min(near, key=lambda x: x[0])
            shoulders[k] = update_tracker(trackers[k], meas)
            if shoulders[k] is None:                    # 마커를 놓치면 Pose 어깨로 대체
                shoulders[k] = pose_sh[k]
                fallback.append(k)

        sl, sr = shoulders["L"], shoulders["R"]
        nose, eye_l, eye_r = pts[PL.NOSE], pts[PL.LEFT_EYE], pts[PL.RIGHT_EYE]

        # 어깨 너비로 정규화한 목 길이(코~어깨 중점 세로 거리)와 얼굴 크기(눈 사이 거리)
        sw = max(math.dist(sl, sr), 1)
        mid = ((sl[0] + sr[0]) // 2, (sl[1] + sr[1]) // 2)
        neck = (mid[1] - nose[1]) / sw
        face = math.dist(eye_l, eye_r) / sw
        tilt = math.degrees(math.atan2(sr[1] - sl[1], sr[0] - sl[0]))

        color = YELLOW              # 캘리브레이션 중 색
        if base is None:
            # 캘리브레이션: 처음 CALIB_SEC 동안의 값(중앙값)을 바른 자세 기준으로 저장
            calib_start = calib_start or now
            calib.append((neck, face))
            remain = CALIB_SEC - (now - calib_start)
            put_text(frame, f"Keep good posture for {CALIB_SEC}s!  {max(remain, 0):.0f}s", (PAD, 25), YELLOW, TEXT_L)
            cv2.rectangle(frame, (PAD, 35), (PAD + int((w - 2 * PAD) * (1 - max(remain, 0) / CALIB_SEC)), 39), YELLOW, -1)  # 진행 바
            if remain <= 0:
                base = tuple(np.median(calib, axis=0))
        else:
            # 점수 = 목 짧아진 비율 + 얼굴 커진 비율 (머리가 앞으로 나오고 처질수록 커짐)
            neck_drop = 1 - neck / base[0]
            face_grow = face / base[1] - 1
            scores.append(neck_drop + face_grow)
            score = sum(scores) / len(scores)

            if score >= BAD_SCORE:
                status, color = "TURTLE NECK", RED
            elif score >= WARN_SCORE:
                status, color = "WARNING", YELLOW
            else:
                status, color = "GOOD", GREEN

            label = status + (f" (pose shoulder: {','.join(fallback)})" if fallback else "")
            put_text(frame, label, (PAD, 25), color, TEXT_L)
            put_text(frame, f"Neck {-neck_drop * 100:+.0f}%  Face {face_grow * 100:+.0f}%", (PAD, 50))

        # 판정 결과 색으로 어깨선, 목 길이 선, 눈 사이 선 그리기 (마커 검출 어깨는 채운 점, Pose 대체 어깨는 빈 원)
        cv2.line(frame, sl, sr, color, LINE, cv2.LINE_AA)
        cv2.line(frame, mid, (mid[0], nose[1]), color, LINE, cv2.LINE_AA)
        cv2.line(frame, eye_l, eye_r, color, LINE, cv2.LINE_AA)
        for k, p in shoulders.items():
            cv2.circle(frame, p, DOT + 2, color, 2 if k in fallback else -1, cv2.LINE_AA)
        for p in (nose, eye_l, eye_r):
            cv2.circle(frame, p, DOT, color, -1, cv2.LINE_AA)

        put_text(frame, f"Shoulder tilt {tilt:+.1f} deg", (PAD, 70), RED if abs(tilt) >= TILT_DEG else WHITE)
    else:
        put_text(frame, "No person detected", (PAD, 25), RED, TEXT_L)

    # 시간 누적, 거북목이 ALERT_SEC 이상 지속되면 화면 전체 빨간 경고
    if status == "TURTLE NECK":
        bad_t += dt
        bad_since = bad_since or now
        if now - bad_since >= ALERT_SEC:
            cv2.addWeighted(np.full_like(frame, RED), 0.3, frame, 0.7, 0, frame)
            put_text(frame, f"STRAIGHTEN UP!  {now - bad_since:.0f}s", (PAD, 100), scale=TEXT_L)
    else:
        bad_since = None
        if status:
            good_t += dt

    # 하단 바른 자세 비율 바
    ratio = good_t / (good_t + bad_t) if good_t + bad_t > 0 else 1.0
    cv2.rectangle(frame, (PAD, h - 20), (w - PAD, h - 12), RED, -1)
    cv2.rectangle(frame, (PAD, h - 20), (PAD + int((w - 2 * PAD) * ratio), h - 12), GREEN, -1)
    put_text(frame, f"Good posture {ratio * 100:.0f}%", (PAD, h - 28))

    cv2.imshow("Turtle Neck Detector", frame)
    cv2.imshow("mask", mask)

pose_detector.close()
cap.release()
cv2.destroyAllWindows()
