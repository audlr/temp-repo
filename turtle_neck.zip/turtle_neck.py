import cv2
import math
import time
import numpy as np
import mediapipe as mp
from collections import deque
from numpy.linalg import inv
from mediapipe.tasks import python
from mediapipe.tasks.python import vision


# ---------------- 설정 ----------------
MODEL_PATH = "src/models/MediaPipe/pose_landmarker.task"

# 판정
WARN_SCORE, BAD_SCORE = 0.15, 0.20  # 기준 자세 대비 변화량 (목 짧아짐 + 얼굴 커짐) 이상이면 주의 / 거북목
CALIB_SEC = 10                      # 캘리브레이션 시간(초)
ALERT_SEC = 5                       # 거북목 자세가 이 시간(초) 이상 지속되면 경고

# 전처리
ALPHA, BETA = 1.1, 10               # 대비, 밝기
CLAHE_CLIP, CLAHE_TILE = 2.0, 8     # CLAHE 대비 제한, 타일 크기
BLUR_K, MORPH_K = 7, 5              # 가우시안 블러, 모폴로지 커널 크기
OPEN_ITER, CLOSE_ITER = 2, 3        # 열림 / 닫힘 연산 반복 횟수

# 어깨 마커
LAB_LOW = np.array([30, 60, 90], dtype=np.uint8)       # 초록 LAB 범위
LAB_HIGH = np.array([230, 115, 180], dtype=np.uint8)
SEARCH_RATIO = 0.35                 # Pose 어깨에서 어깨 너비의 이 비율 이내만 마커 탐색
MIN_AREA = 80                       # 마커로 인정할 최소 윤곽선 면적
LOST_LIMIT = 15                     # 마커를 이 프레임 수 이상 놓치면 Pose 어깨로 대체

# 표시 (BGR)
GREEN, YELLOW, RED, WHITE = (0, 200, 0), (0, 200, 255), (0, 0, 255), (255, 255, 255)
LINE, DOT = 3, 5                    # 선 두께, 점 반지름
TEXT, TEXT_L = 0.5, 0.6             # 글자 크기 (보통, 강조)
PAD = 15                            # 화면 여백
WIN = "Turtle Neck Detector"


base_option = python.BaseOptions(model_asset_path=MODEL_PATH)                   # 모델 경로 지정하는 옵션
options = vision.PoseLandmarkerOptions(base_options=base_option, num_poses=1)   # 모델 경로와 최대 사람 수 지정
pose_detector = vision.PoseLandmarker.create_from_options(options)              # 해당 옵션으로 자세 검출하는 객체 생성
PL = vision.PoseLandmark                                                        # landmark 이름 (NOSE, LEFT_EYE 등)

pipeline = (
    "v4l2src device=/dev/video0 ! "
    "video/x-raw,format=YUY2,width=640,height=480,framerate=30/1 ! "
    "videoconvert ! video/x-raw,format=BGR ! "
    "queue leaky=downstream max-size-buffers=1 "
    "max-size-bytes=0 max-size-time=0 ! "
    "appsink drop=true max-buffers=1 sync=false"
)
cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)    # Jetson
# cap = cv2.VideoCapture(0)                            # 노트북 웹캠


# ---------------- Kalman Filter (상태 mu: [[x, y], [vx, vy]]) ----------------
def KalmanFilter(mu_prev, sigma_prev, z):
    mu_bar = A_t.dot(mu_prev)
    sigma_bar = A_t.dot(sigma_prev).dot(A_t.transpose()) + R_t
    if z is None:
        return mu_bar, sigma_bar
    else:
        K_t = sigma_bar.dot(C_t.transpose()).dot(inv(C_t.dot(sigma_bar).dot(C_t.transpose()) + Q_t))
        mu = mu_bar + K_t.dot(z - C_t.dot(mu_bar))
        sigma = (np.identity(2) - K_t.dot(C_t)).dot(sigma_bar)
        return mu, sigma

A_t = np.array([[1, 1], [0, 1]])
G = np.array([[0.5], [1]])
R_t = G.dot(G.transpose())
C_t = np.array([[1, 0]])
Q_t = np.array([[1]])


def track(t, z):
    """측정값 있으면 Prediction & Update, 없으면 Prediction만. LOST_LIMIT 넘게 놓치면 None"""
    if t["mu"] is None:
        if z is None:
            return None
        t["mu"], t["sigma"] = np.array([[z[0], z[1]], [0, 0]]), np.zeros((2, 2))    # 최초 검출 위치에서 시작
    t["lost"] = 0 if z is not None else t["lost"] + 1
    if t["lost"] > LOST_LIMIT:
        t["mu"] = None
        return None
    t["mu"], t["sigma"] = KalmanFilter(t["mu"], t["sigma"], None if z is None else np.array([list(z)]))
    return int(t["mu"][0][0]), int(t["mu"][0][1])


# ---------------- 마커 검출 (어깨 주변 영역만 처리) ----------------
def find_marker(lab, center, r):
    """center 주변 r 범위만 잘라 블러 → 색 분할 → 모폴로지 → center에 가장 가까운 윤곽선 중심"""
    h, w = lab.shape[:2]
    x1, y1 = max(int(center[0] - r), 0), max(int(center[1] - r), 0)
    x2, y2 = min(int(center[0] + r), w), min(int(center[1] + r), h)
    if x2 <= x1 or y2 <= y1:
        return None

    roi = cv2.GaussianBlur(lab[y1:y2, x1:x2], (BLUR_K, BLUR_K), 0)
    mask = cv2.inRange(roi, LAB_LOW, LAB_HIGH)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=OPEN_ITER)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=CLOSE_ITER)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE, offset=(x1, y1))

    best = None
    for c in contours:
        M = cv2.moments(c)
        if M["m00"] > MIN_AREA:                 # m00 = 윤곽선 면적
            p = (M["m10"] / M["m00"], M["m01"] / M["m00"])
            d = math.dist(p, center)
            if d < r and (best is None or d < best[0]):
                best = (d, p)
    return best[1] if best else None


def put_text(img, text, org, color=WHITE, scale=TEXT):
    cv2.putText(img, text, org, cv2.FONT_HERSHEY_SIMPLEX, scale, color, 1, cv2.LINE_AA)


# ---------------- READY 버튼 ----------------
button = (0, 0, 0, 0)       # 버튼 영역 (x1, y1, x2, y2), 첫 프레임에서 화면 가운데로 설정
ready = False


def on_click(event, x, y, flags, param):
    global ready
    if event == cv2.EVENT_LBUTTONDOWN and button[0] <= x <= button[2] and button[1] <= y <= button[3]:
        ready = True


cv2.namedWindow(WIN)
cv2.setMouseCallback(WIN, on_click)

trackers = {k: {"mu": None, "sigma": None, "lost": 0} for k in ("L", "R")}     # 화면 기준 왼쪽 / 오른쪽 어깨
clahe = cv2.createCLAHE(clipLimit=CLAHE_CLIP, tileGridSize=(CLAHE_TILE, CLAHE_TILE))
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (MORPH_K, MORPH_K))
scores = deque(maxlen=10)       # 점수 이동평균용
calib, calib_start = [], None   # 캘리브레이션 샘플, 시작 시각
base = None                     # 기준 자세 (목 길이 비율, 얼굴 크기 비율)
good_t = bad_t = 0.0            # 바른 자세 / 거북목 누적 시간
bad_since = None                # 거북목 자세 시작 시각
prev = time.time()

while True:
    ret, frame = cap.read()

    if not ret:
        break
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
    if key == ord(" "):         # 스페이스로도 시작
        ready = True
    if key == ord("c"):         # 처음(READY 버튼)으로
        ready, base, calib, calib_start = False, None, [], None

    now = time.time()
    dt, prev = now - prev, now

    # 전처리: 밝기/대비 조정 → LAB 변환 → L 채널 CLAHE (LAB 영상은 마커 색 분할에 그대로 재사용)
    frame = cv2.convertScaleAbs(frame, alpha=ALPHA, beta=BETA)
    l, a, b = cv2.split(cv2.cvtColor(frame, cv2.COLOR_BGR2LAB))
    lab = cv2.merge((clahe.apply(l), a, b))
    frame = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    h, w = frame.shape[:2]
    button = (w // 2 - 70, h // 2 - 22, w // 2 + 70, h // 2 + 22)

    # 프레임 내 자세 탐지
    result = pose_detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)))
    status = None

    if result.pose_landmarks:
        pts = [(int(p.x * w), int(p.y * h)) for p in result.pose_landmarks[0]]    # 프레임 크기 기준 각 landmark 좌표
        nose, eye_l, eye_r = pts[PL.NOSE], pts[PL.LEFT_EYE], pts[PL.RIGHT_EYE]

        # 어깨: Pose 어깨 주변에서 마커 검출 → Kalman 추적, 놓치면 Pose 어깨로 대체
        s1, s2 = pts[PL.LEFT_SHOULDER], pts[PL.RIGHT_SHOULDER]
        pose_sh = {"L": min(s1, s2), "R": max(s1, s2)}      # 화면 기준 왼쪽 / 오른쪽
        r = SEARCH_RATIO * math.dist(s1, s2)
        sh, fallback = {}, []
        for k in ("L", "R"):
            sh[k] = track(trackers[k], find_marker(lab, pose_sh[k], r))
            if sh[k] is None:
                sh[k] = pose_sh[k]
                fallback.append(k)
        sl, sr = sh["L"], sh["R"]

        # 어깨 너비로 정규화한 목 길이(코~어깨 중점 세로 거리)와 얼굴 크기(눈 사이 거리)
        sw = max(math.dist(sl, sr), 1)
        mid = ((sl[0] + sr[0]) // 2, (sl[1] + sr[1]) // 2)
        neck = (mid[1] - nose[1]) / sw
        face = math.dist(eye_l, eye_r) / sw

        color = YELLOW
        if not ready:
            # 시작 대기 (READY 버튼은 선 위에 보이도록 아래에서 그림)
            put_text(frame, "Click READY (or SPACE) and keep good posture", (PAD, 25), YELLOW, TEXT_L)
        elif base is None:
            # 캘리브레이션: CALIB_SEC 동안의 값(중앙값)을 바른 자세 기준으로 저장
            calib_start = calib_start or now
            calib.append((neck, face))
            remain = max(CALIB_SEC - (now - calib_start), 0)
            put_text(frame, f"Keep good posture...  {remain:.0f}s", (PAD, 25), YELLOW, TEXT_L)
            cv2.rectangle(frame, (PAD, 35), (PAD + int((w - 2 * PAD) * (1 - remain / CALIB_SEC)), 39), YELLOW, -1)
            if remain == 0:
                base = np.median(calib, axis=0)
        else:
            # 점수 = 목 짧아진 비율 + 얼굴 커진 비율 (머리가 앞으로 나오고 처질수록 커짐)
            neck_drop = 1 - neck / base[0]
            face_grow = face / base[1] - 1
            scores.append(neck_drop + face_grow)
            score = sum(scores) / len(scores)

            if score >= BAD_SCORE:
                status, color = "TURTLE NECK", RED
            elif score >= WARN_SCORE:
                status, color = "WARNING", YELLOW
            else:
                status, color = "GOOD", GREEN

            put_text(frame, status + (f" (pose shoulder: {','.join(fallback)})" if fallback else ""), (PAD, 25), color, TEXT_L)
            put_text(frame, f"Neck {-neck_drop * 100:+.0f}%  Face {face_grow * 100:+.0f}%", (PAD, 50))

        # 어깨선, 목 길이 선, 눈 사이 선 (마커 검출 어깨는 채운 점, Pose 대체 어깨는 빈 원)
        cv2.line(frame, sl, sr, color, LINE, cv2.LINE_AA)
        cv2.line(frame, mid, (mid[0], nose[1]), color, LINE, cv2.LINE_AA)
        cv2.line(frame, eye_l, eye_r, color, LINE, cv2.LINE_AA)
        for k, p in sh.items():
            cv2.circle(frame, p, DOT + 2, color, 2 if k in fallback else -1, cv2.LINE_AA)
        for p in (nose, eye_l, eye_r):
            cv2.circle(frame, p, DOT, color, -1, cv2.LINE_AA)

        if not ready:
            cv2.rectangle(frame, button[:2], button[2:], YELLOW, -1)
            put_text(frame, "READY?", (button[0] + 32, button[3] - 14), (0, 0, 0), 0.8)
    else:
        put_text(frame, "No person detected", (PAD, 25), RED, TEXT_L)

    # 시간 누적, 거북목이 ALERT_SEC 이상 지속되면 화면 전체 빨간 경고
    if status == "TURTLE NECK":
        bad_t += dt
        bad_since = bad_since or now
        if now - bad_since >= ALERT_SEC:
            cv2.addWeighted(np.full_like(frame, RED), 0.3, frame, 0.7, 0, frame)
            put_text(frame, f"STRAIGHTEN UP!  {now - bad_since:.0f}s", (PAD, 80), scale=TEXT_L)
    else:
        bad_since = None
        if status:
            good_t += dt

    # 하단 바른 자세 비율 바
    if status:
        ratio = good_t / max(good_t + bad_t, 1e-6)
        cv2.rectangle(frame, (PAD, h - 20), (w - PAD, h - 12), RED, -1)
        cv2.rectangle(frame, (PAD, h - 20), (PAD + int((w - 2 * PAD) * ratio), h - 12), GREEN, -1)
        put_text(frame, f"Good posture {ratio * 100:.0f}%", (PAD, h - 28))

    cv2.imshow(WIN, frame)

pose_detector.close()
cap.release()
cv2.destroyAllWindows()
