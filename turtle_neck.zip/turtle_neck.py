import cv2
import math
import time
import numpy as np
import mediapipe as mp
from collections import deque
from mediapipe.tasks import python
from mediapipe.tasks.python import vision


# ---------------- 설정 ----------------
GOOD_DEG, WARN_DEG = 55, 50     # CVA 55도 이상 정상, 50~55 주의, 50 미만 거북목
ALERT_SEC = 5                   # 거북목 자세가 이 시간(초) 이상 지속되면 경고
MIN_AREA = 80                   # 마커로 인정할 최소 윤곽선 면적
LOST_LIMIT = 15                 # 마커를 이 프레임 수 이상 놓치면 추적 해제
FLIP = 0                        # 0 상하 반전, 1 좌우 반전, None 반전 없음 (노트북 웹캠은 None)

base_option = python.BaseOptions(model_asset_path="src/models/MediaPipe/pose_landmarker.task")  # 모델 경로 지정하는 옵션
options = vision.PoseLandmarkerOptions(base_options=base_option, num_poses=1)                   # 모델 경로와 최대 사람 수 지정
pose_detector = vision.PoseLandmarker.create_from_options(options)                              # 해당 옵션으로 자세 검출하는 객체 생성
connections = vision.PoseLandmarksConnections.POSE_LANDMARKS                                    # 각 landmark를 잇는 연결선 정보
PL = vision.PoseLandmark                                                                        # landmark 이름 (LEFT_EAR 등)


# ---------------- 카메라 ----------------
pipeline = (
    "v4l2src device=/dev/video0 ! "
    "video/x-raw,format=YUY2,width=640,height=480,framerate=30/1 ! "
    "videoconvert ! video/x-raw,format=BGR ! "
    "queue leaky=downstream max-size-buffers=1 "
    "max-size-bytes=0 max-size-time=0 ! "
    "appsink drop=true max-buffers=1 sync=false"
)

cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)    # Jetson
# cap = cv2.VideoCapture(0)                            # 노트북 웹캠 (FLIP = None 으로 변경)


# ---------------- C7 마커 HSV 트랙바 (기본값: 초록 스티커) ----------------
cv2.namedWindow("mask")
for name, init, mx in [("H_low", 35, 179), ("H_high", 85, 179),
                       ("S_low", 80, 255), ("S_high", 255, 255),
                       ("V_low", 60, 255), ("V_high", 255, 255)]:
    cv2.createTrackbar(name, "mask", init, mx, lambda _: None)


# ---------------- C7 마커 추적용 칼만 필터 (위치 x, y + 속도 vx, vy) ----------------
kf = cv2.KalmanFilter(4, 2)
kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)                      # 위치만 측정
kf.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)  # 등속 운동 모델
kf.processNoiseCov = np.eye(4, dtype=np.float32) * 1e-2
kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 1e-1
tracking, lost = False, 0       # 추적 중 여부, 연속으로 놓친 프레임 수
trail = deque(maxlen=40)        # 마커 이동 궤적

clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
kernel = np.ones((5, 5), np.uint8)
angles = deque(maxlen=10)       # 각도 이동평균용
good_t = bad_t = 0.0            # 바른 자세 / 거북목 누적 시간
bad_since = None                # 거북목 자세 시작 시각
prev = time.time()

while True:
    ret, frame = cap.read()

    if not ret:
        break
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
    if key == ord("r"):         # 통계 초기화
        good_t = bad_t = 0.0
        bad_since = None

    now = time.time()
    dt, prev = now - prev, now

    # 이미지 반전, 밝기/대비 조정, LAB 색공간에서 CLAHE로 조명 보정 (전처리)
    if FLIP is not None:
        frame = cv2.flip(frame, FLIP)
    frame = cv2.convertScaleAbs(frame, alpha=1.1, beta=10)
    l, a, b = cv2.split(cv2.cvtColor(frame, cv2.COLOR_BGR2LAB))
    frame = cv2.cvtColor(cv2.merge((clahe.apply(l), a, b)), cv2.COLOR_LAB2BGR)
    h, w = frame.shape[:2]      # 프레임 높이와 너비

    # 블러 후 HSV 변환, 트랙바 범위로 마스크 생성, 모폴로지로 잡티 제거 및 구멍 메우기
    hsv = cv2.cvtColor(cv2.GaussianBlur(frame, (7, 7), 0), cv2.COLOR_BGR2HSV)
    lo = np.array([cv2.getTrackbarPos(n, "mask") for n in ("H_low", "S_low", "V_low")])
    hi = np.array([cv2.getTrackbarPos(n, "mask") for n in ("H_high", "S_high", "V_high")])
    mask = cv2.inRange(hsv, lo, hi)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    # 가장 큰 윤곽선의 중심을 C7 마커 측정값으로 사용
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = [c for c in contours if cv2.contourArea(c) > MIN_AREA]
    meas = None
    if contours:
        marker = max(contours, key=cv2.contourArea)
        M = cv2.moments(marker)
        meas = (M["m10"] / M["m00"], M["m01"] / M["m00"])
        cv2.drawContours(frame, [marker], -1, (255, 255, 0), 2)

    # 칼만 필터로 위치 보정 (마커가 잠깐 가려져도 예측값으로 유지)
    c7 = None
    if not tracking and meas is not None:
        kf.statePost = np.array([[meas[0]], [meas[1]], [0], [0]], np.float32)
        tracking = True
    if tracking:
        est = kf.predict()
        if meas is not None:
            est = kf.correct(np.array([[meas[0]], [meas[1]]], np.float32))
            lost = 0
        else:
            lost += 1
        if lost > LOST_LIMIT:
            tracking = False
            trail.clear()
        else:
            c7 = (float(est[0, 0]), float(est[1, 0]))
            trail.append(c7)

    # 마커 이동 궤적 그리기
    points = [tuple(map(int, p)) for p in trail]
    for p1, p2 in zip(points, points[1:]):
        cv2.line(frame, p1, p2, (255, 200, 0), 1)

    # 프레임 내 자세 탐지
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = pose_detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb))

    if result.pose_landmarks:
        pose = result.pose_landmarks[0]
        pts = [(int(p.x * w), int(p.y * h)) for p in pose]    # 프레임 크기 기준 각 landmark 좌표

        # landmark를 연결하는 선 (skeleton)과 점 그리기
        for c in connections:
            cv2.line(frame, pts[c.start], pts[c.end], (0, 255, 0), 1)
        for pt in pts:
            cv2.circle(frame, pt, 3, (255, 0, 0), -1)

        # 카메라 쪽(가시성이 높은) 귀와 어깨 선택
        left = pose[PL.LEFT_EAR].visibility >= pose[PL.RIGHT_EAR].visibility
        ear = pts[PL.LEFT_EAR if left else PL.RIGHT_EAR]
        shoulder = pts[PL.LEFT_SHOULDER if left else PL.RIGHT_SHOULDER]
        base = tuple(map(int, c7)) if c7 is not None else shoulder    # 마커 없으면 어깨로 대체

        # CVA: 기준점→귀 직선과 수평선 사이 각도, 최근 10프레임 평균
        angles.append(math.degrees(math.atan2(base[1] - ear[1], abs(ear[0] - base[0]))))
        angle = sum(angles) / len(angles)

        if angle >= GOOD_DEG:
            status, color = "GOOD", (0, 200, 0)
        elif angle >= WARN_DEG:
            status, color = "WARNING", (0, 200, 255)
        else:
            status, color = "TURTLE NECK", (0, 0, 255)

        # 수평 기준선, 기준점→귀 선, 각도 호, 각도 텍스트
        front = ear[0] >= base[0]       # 얼굴이 화면 오른쪽을 향하는지
        cv2.line(frame, base, (base[0] + (100 if front else -100), base[1]), (200, 200, 200), 2)
        cv2.line(frame, base, ear, color, 3)
        cv2.circle(frame, ear, 8, color, -1)
        cv2.circle(frame, base, 8, (255, 255, 0), -1)
        cv2.ellipse(frame, base, (50, 50), 0, 0 if front else 180, -angle if front else 180 + angle, color, 2)
        cv2.putText(frame, f"{angle:.1f} deg", (base[0] + 10, base[1] + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        label = status + (" (shoulder fallback)" if c7 is None else "")
        cv2.putText(frame, label, (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

        # 시간 누적, 거북목이 ALERT_SEC 이상 지속되면 화면 전체 빨간 경고
        if status == "TURTLE NECK":
            bad_t += dt
            bad_since = bad_since or now
            if now - bad_since >= ALERT_SEC:
                red = np.full_like(frame, (0, 0, 255))
                cv2.addWeighted(red, 0.3, frame, 0.7, 0, frame)
                cv2.putText(frame, f"STRAIGHTEN UP! {now - bad_since:.0f}s", (20, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)
        else:
            good_t += dt
            bad_since = None
    else:
        bad_since = None
        cv2.putText(frame, "No person detected", (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

    # 하단 바른 자세 비율 바와 우측 상단 FPS
    total = good_t + bad_t
    ratio = good_t / total if total > 0 else 1.0
    cv2.rectangle(frame, (20, h - 40), (w - 20, h - 20), (0, 0, 255), -1)
    cv2.rectangle(frame, (20, h - 40), (20 + int((w - 40) * ratio), h - 20), (0, 200, 0), -1)
    cv2.putText(frame, f"Good posture {ratio * 100:.0f}% ({total:.0f}s)", (20, h - 48), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    cv2.putText(frame, f"{1 / dt if dt > 0 else 0:.1f} FPS", (w - 110, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    cv2.imshow("Turtle Neck Detector", frame)
    cv2.imshow("mask", mask)

pose_detector.close()
cap.release()
cv2.destroyAllWindows()
